import time, os
os.system("color b")
print("Enter 'q' to quit.")
print("--------------------RUN--------------------")
dis = []
while True:
    ynum = input("Enter a number:")
    if ynum == "q":
        break
    num=ynum
    try:
        int(num)
    except:
        print("Wrong number!")
        continue
    num = int(num)
    if num <= 1:
        print("You can't type in 1 or smaller Numbers!")
        continue
    start = time.time()
    for i in range(2,num):
        while True:
            if num % i == 0:
                dis.append(i)
                num = num / i
            else:
                break
        if num == 1:
            break
    if len(dis) == 0:
        print("\n", str(ynum) + " is prime!")
    else:
        print("The result of the prime factorization of " + ynum + " is:")
        print(dis)
    end = time.time()
    end = end - start
    end = "%.3f" % end
    print("\n(About used:",str(end),"s)\n")
    dis = []
os.system("cls")
print("\nThank you for using this software!\n")
input("Press enter to quit...")
